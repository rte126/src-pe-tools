-- Team: Smiling Solo
-- Project: Patch Request Application

-- session variables

variable curuser number;


