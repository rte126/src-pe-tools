-- session variables

variable curuser number;


