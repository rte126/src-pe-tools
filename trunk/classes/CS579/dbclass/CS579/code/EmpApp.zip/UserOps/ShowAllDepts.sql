-- ShowAllDepts
-- Show the numbers, names & locations of all departments

SELECT deptno, dname, loc FROM Depts
  ORDER BY deptno;



