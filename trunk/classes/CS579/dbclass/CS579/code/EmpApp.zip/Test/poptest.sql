prompt
prompt Team: Data Junkies
prompt Populate Test for Employee Database Application
-- Ellis S. Cohen

prompt ****** TABLES

prompt
prompt Emps Table
select * from Emps;
prompt $$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$

prompt
prompt Depts Table
select * from Depts;
prompt $$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$

prompt
prompt ****** MANIFEST VIEWS

prompt
prompt DeptMgrsView
select * from DeptMgrsView;
prompt $$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$

prompt
prompt DeptMgrClerksView
select * from DeptMgrClerksView;
prompt $$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$

prompt
prompt ManageLocView
select * from ManageLocView;
prompt $$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$

prompt
prompt DeptActMgrView
select * from DeptActMgrView;
prompt $$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$









