-- Team: Data Junkies
-- Employee Database Application

prompt 
prompt =====================================================
prompt 
prompt This tests operations assigned to the User role
prompt   Queries: ShowAllDepts
prompt
pause Hit Return to test User role operations

prompt
prompt ==> Show #, name and location of all departments
@&u/ShowAllDepts





