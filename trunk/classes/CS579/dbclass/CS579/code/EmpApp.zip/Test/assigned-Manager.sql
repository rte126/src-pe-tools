-- Team: Data Junkies
-- Employee Database Application

prompt
prompt =====================================================
prompt 
prompt This tests operations assigned to the Manager Role
prompt but not assigned to any of its super-roles
prompt   Queries: ShowDirect, ShowBelow
prompt
pause Hit Return to test Manager role operations

prompt
prompt ==> Show info of employees who report directly to me
@&u\ShowDirect

prompt
prompt ==> Show info of employees who are below me in the management hierarchy
@&u\ShowBelow





