prompt
prompt Team: Data Junkies
prompt Transition Constraint Tests for Employee Database Application
prompt
prompt Test each enforced transition constraint separately
prompt Each constraint is checked by 
prompt making sure that enforcement by rejection causes the corrseponding failures
prompt and that enforcement by correction produces the corresponding side effects
prompt
prompt Note: Generally no need to test cases where operations succeed;
prompt That should have been tested in the basic tests
prompt
prompt Note: to the extent possible, the operations tested
prompt do not violate any access constraints or other pre-conditions
prompt

@@transition-OnLoseMgr



