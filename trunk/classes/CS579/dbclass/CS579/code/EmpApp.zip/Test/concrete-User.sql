-- Team: Data Junkies
-- Employee Database Application

prompt
prompt $$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$
prompt
prompt *** Basic User Test
prompt
prompt Make sure user is not logged in
prompt Then test operations that a user who is not logged in can do
prompt 
pause Hit Return to start the Basic User Test

prompt
prompt ==> Logout if necessary (may fail)
@&u\Logout

-- now test operations assigned to the User role
@@assigned-User

prompt
prompt  *** Completed Basic User Test
