-- create a new user
-- you must connect as the super user

create user &1 identified by OK;

@@givepriv &1;









