-- create a new user and password
-- you must connect as the super user

create user &1 identified by &2;

@@givepriv &1;






